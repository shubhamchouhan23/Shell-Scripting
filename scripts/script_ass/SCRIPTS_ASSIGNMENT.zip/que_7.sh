#!/bin/bash

echo "Current date is `date`"
echo "Username is $LOGNAME"
echo "Current direcotry is `pwd`"
